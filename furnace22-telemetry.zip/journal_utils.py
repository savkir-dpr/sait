from telemetry import publish_journal_event

import json
import os
from datetime import datetime


def _safe_filename(path: str) -> str:
    return path.replace('\\', '/')


def journal_path(storage_path: str) -> str:
    base_dir = os.path.dirname(__file__) if '__file__' in globals() else os.getcwd()
    p = storage_path
    if not os.path.isabs(p):
        p = os.path.join(base_dir, p)
    return _safe_filename(p)


def load_journal(filepath: str) -> list[dict]:
    if not os.path.exists(filepath):
        return []
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        items = data.get('events', [])
        return items if isinstance(items, list) else []
    except Exception:
        return []


def journal_text_path(filepath: str) -> str:
    """Возвращает путь к читаемой текстовой копии JSON-журнала."""
    root, _extension = os.path.splitext(filepath)
    return f'{root}.txt'


def _write_text_journal(filepath: str, events: list[dict]):
    with open(journal_text_path(filepath), 'w', encoding='utf-8') as f:
        for event in events:
            date = str(event.get('date', '')).strip()
            event_time = str(event.get('time', '')).strip()
            program = str(event.get('program', '(без названия)')).strip()
            action = str(event.get('action', 'событие')).strip()
            details = str(event.get('details', '')).strip()
            line = f'[{date} {event_time}] {program} — {action}'
            if details:
                line += f': {details}'
            f.write(f'{line}\n')


def write_journal(filepath: str, events: list[dict]):
    os.makedirs(os.path.dirname(filepath) or '.', exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump({'events': events}, f, ensure_ascii=False, indent=2)
    _write_text_journal(filepath, events)


def journal_add_event(program_name: str, action: str, storage_path: str = 'journal.json', details: str = ''):
    fp = journal_path(storage_path)
    events = load_journal(fp)

    now = datetime.now()
    events.append({
        'ts': now.isoformat(timespec='seconds'),
        'date': now.strftime('%d.%m.%Y'),
        'time': now.strftime('%H:%M:%S'),
        'program': program_name or '(без названия)',
        'action': action,
        'details': details or ''
    })

    events = events[-500:]
    write_journal(fp, events)

    try:
        queued = publish_journal_event(
            action=action,
            program=program_name or "(без названия)",
            details=details or "",
        )
        if not queued:
            print("Событие сохранено локально: телеметрия не настроена")
    except Exception as exc:
        print(f"Не удалось поставить событие в очередь: {exc}")
