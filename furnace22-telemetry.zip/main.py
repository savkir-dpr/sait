from pathlib import Path
from dataclasses import replace
from telemetry import TelemetryConfig, TelemetryPublisher

import customtkinter as ctk
from PIL import Image

from ui_components import LightBackgroundCanvas, NavItem
from manual_page import build_manual_page
from programs_page import build_programs_page
from journal_page import build_journal_page
from ui_metrics import (
    TOUCH_CONTROL_HEIGHT,
    TOUCH_ICON_SIZE,
    TOUCHSCREEN_HEIGHT,
    TOUCHSCREEN_WIDTH,
)

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")


# Абсолютный путь к каталогу проекта. Thonny может запускать файл с рабочим
# каталогом /home/kirill, поэтому относительный путь ``icon/j.png`` не всегда
# указывает на папку icon рядом с main.py.
PROJECT_DIR = Path(__file__).resolve().parent


def _load_nav_icon(
    icon_path: str,
    fallback: str,
    size=(TOUCH_ICON_SIZE, TOUCH_ICON_SIZE),
):
    """Загружает PNG-иконку и возвращает CTkImage без зависимости от шрифтов ОС."""
    try:
        img = Image.open(icon_path).convert("RGBA")
        return ctk.CTkImage(light_image=img, dark_image=img, size=size)
    except Exception as exc:
        # Панель не должна становиться пустой, если PNG отсутствует или Pillow
        # не смог его прочитать. Короткая подпись остаётся рабочей кнопкой.
        print(f"Не удалось загрузить иконку {icon_path}: {exc}")
        return fallback


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.configure(fg_color="#FFFFFF")
        self.title("")
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        width = min(TOUCHSCREEN_WIDTH, screen_width)
        height = min(TOUCHSCREEN_HEIGHT, screen_height)
        x = max(0, (screen_width - width) // 2)
        y = max(0, (screen_height - height) // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")
        self.minsize(min(960, screen_width), min(600, screen_height))
        # Полноэкранный режим убирает панели рабочего стола и рамку окна,
        # которые на 10-дюймовом экране отнимали часть высоты интерфейса.
        self._fullscreen = True
        self.attributes("-fullscreen", True)
        self.bind("<F11>", self._toggle_fullscreen)
        self.bind("<Escape>", self._leave_fullscreen)

        # 🔤 Шрифты из папки
        base_dir = PROJECT_DIR
        self.telemetry = None
        try:
            config = TelemetryConfig.from_file(base_dir / "telemetry_config.json")
            queue_path = Path(config.queue_path)
            if not queue_path.is_absolute():
                config = replace(config, queue_path=str(base_dir / queue_path))
            self.telemetry = TelemetryPublisher(config)
        except Exception as exc:
            print(f"Не удалось настроить телеметрию: {exc}")

        fonts_dir = base_dir / "fonts"

        for font_name in ("Montserrat-SemiBold.ttf", "Montserrat-Regular.ttf"):
            font_path = fonts_dir / font_name
            if font_path.exists():
                try:
                    ctk.FontManager.load_font(str(font_path))
                except Exception:
                    pass

        self.NAV_ACCENT = "#4B0082"

        self.bg = LightBackgroundCanvas(self)
        self.bg.place(relx=0, rely=0, relwidth=1, relheight=1)

        self.page_host = ctk.CTkFrame(self, fg_color="#FFFFFF")
        self.page_host.place(relx=0.03, rely=0.03, relwidth=0.94, relheight=0.81)

        self.nav = ctk.CTkFrame(
            self,
            fg_color="#E3E8F2",
            corner_radius=26,
            border_width=1,
            border_color="#CDD5E3"
        )
        self.nav.place(relx=0.10, rely=0.86, relwidth=0.80, relheight=0.12)

        self.nav.grid_columnconfigure((0, 1, 2), weight=1)
        self.nav.grid_rowconfigure(0, weight=1)

        self.pages = {
            "journal": build_journal_page(self.page_host, accent=self.NAV_ACCENT),
            "manual": build_manual_page(self.page_host, accent=self.NAV_ACCENT),
            "programs": build_programs_page(self.page_host, accent=self.NAV_ACCENT),
        }

        self.order = ["journal", "manual", "programs"]
        self.current_key = "manual"
        self.current_frame = None

        icon_dir = base_dir / "icon"
        # Храним CTkImage на уровне App. Это гарантирует, что Tk не потеряет
        # изображения после завершения __init__ или переключения страниц.
        self.nav_icons = {
            "journal": _load_nav_icon(str(icon_dir / "j.png"), "Ж"),
            "manual": _load_nav_icon(str(icon_dir / "h.png"), "Р"),
            "programs": _load_nav_icon(str(icon_dir / "p.png"), "П"),
        }

        self.items = []
        self.items.append(self._add_item(0, self.nav_icons["journal"], lambda: self.show("journal")))
        self.items.append(self._add_item(1, self.nav_icons["manual"], lambda: self.show("manual")))
        self.items.append(self._add_item(2, self.nav_icons["programs"], lambda: self.show("programs")))

        self.show("manual", first=True)
        self.protocol("WM_DELETE_WINDOW", self._on_close_request)
        self.exit_dialog = None

    def _add_item(self, col, icon, cmd):
        item = NavItem(
            self.nav,
            icon=icon,
            command=cmd,
            accent=self.NAV_ACCENT,
            inactive_color="#111827"
        )
        item.grid(row=0, column=col, sticky="nsew", padx=6, pady=6)
        return item

    def _toggle_fullscreen(self, _event=None):
        self._fullscreen = not self._fullscreen
        self.attributes("-fullscreen", self._fullscreen)

    def _leave_fullscreen(self, _event=None):
        self._fullscreen = False
        self.attributes("-fullscreen", False)

    def show(self, key: str, first=False):
        if key == self.current_key and not first:
            return

        idx = self.order.index(key)

        for it in self.items:
            it.set_active(False)
        self.items[idx].set_active(True)

        new_frame = self.pages[key]
        if self.current_frame is not None:
            self.current_frame.place_forget()

        new_frame.place(relx=0.0, rely=0.0, relwidth=1.0, relheight=1.0)
        self.current_frame = new_frame
        self.current_key = key

    def _on_close_request(self):
        if self.exit_dialog is not None and self.exit_dialog.winfo_exists():
            self.exit_dialog.lift()
            self.exit_dialog.focus_force()
            return

        dialog = ctk.CTkToplevel(self)
        dialog.title("")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        dialog.attributes("-topmost", True)
        self.exit_dialog = dialog

        width, height = 360, 170
        self.update_idletasks()
        x = self.winfo_rootx() + (self.winfo_width() - width) // 2
        y = self.winfo_rooty() + (self.winfo_height() - height) // 2
        dialog.geometry(f"{width}x{height}+{x}+{y}")

        msg = ctk.CTkLabel(
            dialog,
            text="Желаете выйти?",
            font=("Montserrat", 18, "bold"),
            text_color="#111827"
        )
        msg.pack(pady=(30, 20))

        buttons = ctk.CTkFrame(dialog, fg_color="transparent")
        buttons.pack(pady=(0, 20))

        stay_btn = ctk.CTkButton(
            buttons,
            text="остаться",
            width=150,
            height=TOUCH_CONTROL_HEIGHT,
            command=self._dismiss_exit_dialog
        )
        stay_btn.grid(row=0, column=0, padx=8)

        exit_btn = ctk.CTkButton(
            buttons,
            text="выйти",
            width=150,
            height=TOUCH_CONTROL_HEIGHT,
            fg_color="#DC2626",
            hover_color="#B91C1C",
            command=self.destroy
        )
        exit_btn.grid(row=0, column=1, padx=8)

        dialog.protocol("WM_DELETE_WINDOW", self._dismiss_exit_dialog)

    def _dismiss_exit_dialog(self):
        if self.exit_dialog is not None and self.exit_dialog.winfo_exists():
            self.exit_dialog.grab_release()
            self.exit_dialog.destroy()
        self.exit_dialog = None


if __name__ == "__main__":
    app = App()
    app.mainloop()
