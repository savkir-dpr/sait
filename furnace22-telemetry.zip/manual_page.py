import json
import math
import os
import time
import tkinter as tk
from collections import deque
import customtkinter as ctk

from max31865_reader import QuadMAX31865
from pressure_sensor import PressureSensor
from door_sensors import DoorSensors, get_door_sensors
from control_state import is_program_active, request_program_stop
from heater_dimmer import (
    DEFAULT_POWER_PERCENT,
    get_heater_1_dimmer,
    get_heater_2_dimmer,
    get_heater_3_dimmer,
)
from pump_relay import get_pump_relay
from valve_relay import get_valve_relay
from temperature_control import DEFAULT_TARGET_C, ThreeZoneTemperatureController
from ui_metrics import TOUCH_CONTROL_HEIGHT, TOUCH_TOGGLE_WIDTH
from graph_utils import temperature_axis_bounds
from journal_utils import journal_add_event


class ToggleButton(ctk.CTkButton):
    """
    Toggle-кнопка:
    OFF -> красная (выкл)
    ON  -> зелёная (вкл)
    """
    def __init__(
        self,
        master,
        variable=None,
        width=TOUCH_TOGGLE_WIDTH,
        height=TOUCH_CONTROL_HEIGHT,
        on_color="#16A34A",
        off_color="#DC2626",
        **kwargs
    ):
        self.var = variable if variable is not None else ctk.BooleanVar(value=False)
        self._on_color = on_color
        self._off_color = off_color

        super().__init__(
            master,
            width=width,
            height=height,
            text="выкл",
            fg_color=self._off_color,
            hover_color="#B91C1C",
            text_color="#FFFFFF",
            font=ctk.CTkFont(family="Montserrat", size=13, weight="bold"),
            corner_radius=999,
            border_width=2,
            border_color="#FFFFFF",
            command=self.toggle,
            **kwargs
        )
        self._update_style()

    def toggle(self):
        self.var.set(not self.var.get())
        self._update_style()

    def _update_style(self):
        if self.var.get():
            self.configure(text="вкл", fg_color=self._on_color, hover_color="#15803D")
        else:
            self.configure(text="выкл", fg_color=self._off_color, hover_color="#B91C1C")


class AverageTemperatureGraph(ctk.CTkFrame):
    """График средней температуры за 30 минут с шагом 5 секунд."""

    def __init__(
        self,
        master,
        history_seconds: float = 1800.0,
        sample_interval_seconds: float = 5.0,
        **kwargs,
    ):
        super().__init__(
            master,
            height=180,
            fg_color="#F8FAFC",
            corner_radius=12,
            border_width=1,
            border_color="#D1D9E6",
            **kwargs,
        )
        self.grid_propagate(False)
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self._history_seconds = max(5.0, float(history_seconds))
        self._sample_interval_seconds = max(0.1, float(sample_interval_seconds))
        max_samples = int(self._history_seconds / self._sample_interval_seconds) + 1
        self._samples = deque(maxlen=max_samples)
        self._target_c = None
        self._canvas = tk.Canvas(self, bg="#F8FAFC", highlightthickness=0, bd=0)
        self._canvas.grid(row=0, column=0, sticky="nsew", padx=8, pady=5)
        self._canvas.bind("<Configure>", lambda _event: self._redraw_graph())

    def add_sample(self, value: float | None, target_c: float | None = None):
        target_changed = target_c != self._target_c
        self._target_c = target_c
        if value is None:
            if target_changed:
                self._redraw_graph()
            return

        now = time.monotonic()
        if self._samples and now - self._samples[-1][0] < self._sample_interval_seconds:
            if target_changed:
                self._redraw_graph()
            return

        self._samples.append((now, float(value)))
        while self._samples and now - self._samples[0][0] > self._history_seconds:
            self._samples.popleft()
        self._redraw_graph()

    def _redraw_graph(self):
        # Имя _draw зарезервировано CTkFrame: CustomTkinter вызывает его
        # из __init__ с аргументом no_color_updates. Отдельное имя не перекрывает
        # внутреннюю отрисовку рамки.
        canvas = self._canvas
        canvas.delete("all")
        width = canvas.winfo_width()
        height = canvas.winfo_height()
        if width < 80 or height < 50:
            return

        # Заголовок и текущее значение занимают отдельную строку. Область
        # построения начинается ниже, чтобы верхняя подпись оси Y не
        # накладывалась на заголовок даже при масштабировании интерфейса.
        left, right, top, bottom = 50, width - 12, 42, height - 30
        canvas.create_text(8, 6, anchor="nw", text="Средняя температура", fill="#334155", font=("Montserrat", 10, "bold"))
        if not self._samples:
            canvas.create_text(width / 2, height / 2, text="ожидание данных", fill="#94A3B8", font=("Montserrat", 10))
            return

        values = [value for _, value in self._samples]
        scale_values = values + ([self._target_c] if self._target_c is not None else [])
        plot_height = max(1, bottom - top)
        low, high, y_step = temperature_axis_bounds(scale_values, plot_height)

        def y_for(value):
            return bottom - (value - low) / (high - low) * (bottom - top)

        for value in range(int(low), int(high) + 1, y_step):
            y = y_for(value)
            canvas.create_line(left, y, right, y, fill="#E2E8F0")
            canvas.create_text(left - 5, y, anchor="e", text=str(value), fill="#64748B", font=("Montserrat", 8))

        if self._target_c is not None:
            target_y = y_for(self._target_c)
            canvas.create_line(left, target_y, right, target_y, fill="#DC2626", dash=(5, 4), width=1)

        first_time = self._samples[0][0]
        latest_time = self._samples[-1][0]
        if len(self._samples) == 1:
            x_values = [(left + right) / 2]
            visible_seconds = self._sample_interval_seconds
        else:
            # Пока не накопилось 30 минут данных, растягиваем фактическую
            # историю на всю ширину. После заполнения окна шкала остаётся
            # фиксированной и показывает последние 30 минут.
            actual_span = latest_time - self._samples[0][0]
            visible_seconds = min(self._history_seconds, max(self._sample_interval_seconds, actual_span))
            window_start = latest_time - visible_seconds
            x_values = [
                left + (sample_time - window_start) / visible_seconds * (right - left)
                for sample_time, _ in self._samples
            ]

        # Ось X начинается с нуля и показывает фактически накопленный период.
        # Продолжительность округляется до целой минуты, поэтому на шкале нет
        # дробных подписей. После заполнения окна крайняя отметка остаётся 30.
        actual_span_seconds = max(0.0, latest_time - first_time)
        displayed_minutes = min(30, max(1, int(actual_span_seconds / 60.0 + 0.5)))
        minute_ticks = list(range(0, displayed_minutes + 1, 5))
        if minute_ticks[-1] != displayed_minutes:
            minute_ticks.append(displayed_minutes)
        for minute in minute_ticks:
            tick_x = left + minute / displayed_minutes * (right - left)
            canvas.create_line(tick_x, bottom, tick_x, bottom + 4, fill="#94A3B8")
            caption = str(minute)
            anchor = "e" if minute == displayed_minutes else ("w" if minute == 0 else "center")
            canvas.create_text(tick_x, height - 3, anchor=f"s{anchor}" if anchor != "center" else "s", text=caption, fill="#94A3B8", font=("Montserrat", 8))
        points = [(x, y_for(value)) for x, value in zip(x_values, values)]
        if len(points) > 1:
            coordinates = [coordinate for point in points for coordinate in point]
            canvas.create_line(*coordinates, fill="#2563EB", width=3, smooth=True)
        x, y = points[-1]
        canvas.create_oval(x - 3, y - 3, x + 3, y + 3, fill="#2563EB", outline="")
        canvas.create_text(right, 4, anchor="ne", text=f"{values[-1]:.1f} °C", fill="#2563EB", font=("Montserrat", 11, "bold"))



def _confirm_dialog(parent, message: str, on_yes):
    dialog = ctk.CTkToplevel(parent)
    dialog.title("")
    dialog.resizable(False, False)
    dialog.transient(parent.winfo_toplevel())
    dialog.grab_set()

    width, height = 380, 170
    parent.update_idletasks()
    root = parent.winfo_toplevel()
    x = root.winfo_rootx() + (root.winfo_width() - width) // 2
    y = root.winfo_rooty() + (root.winfo_height() - height) // 2
    dialog.geometry(f"{width}x{height}+{x}+{y}")

    ctk.CTkLabel(dialog, text=message, font=("Montserrat", 16, "bold")).pack(pady=(30, 20))

    row = ctk.CTkFrame(dialog, fg_color="transparent")
    row.pack()

    def _yes():
        on_yes()
        dialog.grab_release()
        dialog.destroy()

    def _no():
        dialog.grab_release()
        dialog.destroy()

    ctk.CTkButton(row, text="да", width=140, height=TOUCH_CONTROL_HEIGHT, fg_color="#DC2626", hover_color="#B91C1C", command=_yes).grid(row=0, column=0, padx=8)
    ctk.CTkButton(row, text="нет", width=140, height=TOUCH_CONTROL_HEIGHT, command=_no).grid(row=0, column=1, padx=8)
    dialog.protocol("WM_DELETE_WINDOW", _no)


def _clamp(v: int) -> int:
    if v < 0:
        return 0
    if v > 100:
        return 100
    return v


def _format_pct(v: int) -> str:
    return f"{int(v)}%"


def _parse_pct(text: str, fallback: int) -> int:
    s = text.strip().replace(" ", "")
    if s.endswith("%"):
        s = s[:-1]
    if s == "":
        return fallback
    try:
        return int(float(s))
    except ValueError:
        return fallback


def _load_programs_json(filepath: str) -> list[dict]:
    if not os.path.exists(filepath):
        return []
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        progs = data.get("programs", [])
        return progs if isinstance(progs, list) else []
    except Exception:
        return []


def _program_total_seconds(program: dict) -> int:
    total = 0
    for s in _expand_steps(program):
        try:
            sec = int(float(s.get("seconds", 0) or 0))
        except Exception:
            sec = 0
        total += max(0, sec)
    return total


def _table_row(parent, row: int, name: str, has_percent: bool, var: ctk.BooleanVar):
    parent.grid_columnconfigure(0, weight=1)
    parent.grid_columnconfigure(1, weight=0)
    parent.grid_columnconfigure(2, weight=0)

    name_lbl = ctk.CTkLabel(
        parent,
        text=name,
        font=ctk.CTkFont(family="Montserrat", size=15, weight="normal"),
        text_color="#0B1220",
        width=160,
        anchor="w"
    )
    name_lbl.grid(row=row, column=0, sticky="w", padx=(14, 10), pady=2)

    power_var = None
    power_entry = None

    if has_percent:
        power_var = ctk.IntVar(value=0)
        power_entry = ctk.CTkEntry(
            parent,
            width=90,
            height=TOUCH_CONTROL_HEIGHT,
            justify="center",
            font=ctk.CTkFont(family="Montserrat", size=11, weight="normal"),
            placeholder_text="0-100%"
        )
        power_entry.grid(row=row, column=1, sticky="w", padx=(0, 10), pady=2)

        def _apply(_event=None):
            v = _parse_pct(power_entry.get(), fallback=power_var.get())
            v = _clamp(v)
            power_var.set(v)
            power_entry.delete(0, "end")
            power_entry.insert(0, _format_pct(v))

        power_entry.bind("<Return>", _apply)
        power_entry.bind("<FocusOut>", _apply)
        power_entry.insert(0, _format_pct(0))
    else:
        spacer = ctk.CTkFrame(parent, fg_color="transparent", width=90, height=TOUCH_CONTROL_HEIGHT)
        spacer.grid(row=row, column=1, sticky="w", padx=(0, 10), pady=2)
        spacer.grid_propagate(False)

    btn = ToggleButton(parent, variable=var)
    btn.grid(row=row, column=2, sticky="w", padx=(0, 14), pady=2)

    return {"var": var, "toggle": btn, "power_var": power_var, "power_entry": power_entry}


def _table_status_row(parent, row: int, name: str, is_open: bool = False):
    parent.grid_columnconfigure(0, weight=1)
    parent.grid_columnconfigure(1, weight=0)
    parent.grid_columnconfigure(2, weight=0)

    name_lbl = ctk.CTkLabel(
        parent,
        text=name,
        font=ctk.CTkFont(family="Montserrat", size=15, weight="normal"),
        text_color="#0B1220",
        width=160,
        anchor="w"
    )
    name_lbl.grid(row=row, column=0, sticky="w", padx=(14, 10), pady=2)

    spacer = ctk.CTkFrame(parent, fg_color="transparent", width=90, height=TOUCH_CONTROL_HEIGHT)
    spacer.grid(row=row, column=1, sticky="w", padx=(0, 10), pady=2)
    spacer.grid_propagate(False)

    state_row = ctk.CTkFrame(parent, fg_color="transparent")
    state_row.grid(row=row, column=2, sticky="w", padx=(0, 14), pady=2)

    lamp = ctk.CTkLabel(
        state_row,
        text="●",
        font=ctk.CTkFont(family="Montserrat", size=16, weight="bold"),
        text_color="#16A34A" if is_open else "#DC2626"
    )
    lamp.pack(side="left", padx=(0, 6))

    status_lbl = ctk.CTkLabel(
        state_row,
        text="закрыта" if is_open else "открыта",
        text_color="#16A34A" if is_open else "#DC2626",
        font=ctk.CTkFont(family="Montserrat", size=12, weight="bold")
    )
    status_lbl.pack(side="left")

    return {"status_label": status_lbl, "lamp": lamp, "is_open": is_open}


def _door_indicator_row(parent, title: str):
    """Совместимость со старыми вызовами: индикатор концевика."""
    row = ctk.CTkFrame(parent, fg_color="transparent")
    row.pack(anchor="w", pady=(0, 4))
    ctk.CTkLabel(row, text=title, font=ctk.CTkFont("Montserrat", 12), text_color="#6B7280").pack(side="left", padx=(0, 8))
    lamp = ctk.CTkLabel(row, text="●", font=ctk.CTkFont("Montserrat", 16, "bold"), text_color="#9CA3AF")
    lamp.pack(side="left", padx=(0, 6))
    text = ctk.CTkLabel(row, text="--", font=ctk.CTkFont("Montserrat", 12, "bold"), text_color="#9CA3AF")
    text.pack(side="left")
    return lamp, text

def _paint_door_indicator(lamp, text_lbl, closed):
    if closed is None:
        lamp.configure(text_color='#9CA3AF')
        text_lbl.configure(text='--', text_color='#9CA3AF')
    elif closed:
        lamp.configure(text_color='#16A34A')
        text_lbl.configure(text='закрыта', text_color='#16A34A')
    else:
        lamp.configure(text_color='#DC2626')
        text_lbl.configure(text='открыта', text_color='#DC2626')

def _step_seconds(step: dict) -> int:
    if "seconds" in step:
        try:
            return max(0, int(float(step.get("seconds", 0) or 0)))
        except Exception:
            return 0
    try:
        return max(0, int(float(step.get("seconds_on", 0) or 0)))
    except Exception:
        return 0


def _expand_steps(program: dict) -> list[dict]:
    expanded: list[dict] = []
    steps = program.get("steps", []) or []

    for s in steps:
        parallel = s.get("parallel")
        if isinstance(parallel, list) and parallel:
            for part in parallel:
                dev = str(part.get("device", "")).strip().lower()
                if not dev:
                    continue
                enabled = bool(part.get("enabled", False))
                t1 = _step_seconds(part)
                try:
                    t2 = max(0, int(float(part.get("seconds_off", 0) or 0)))
                except Exception:
                    t2 = 0
                if t1 > 0:
                    expanded.append({"device": dev, "enabled": enabled, "seconds": t1})
                if t2 > 0:
                    expanded.append({"device": dev, "enabled": (not enabled), "seconds": t2})
            continue

        raw_devices = s.get("devices")
        if isinstance(raw_devices, list):
            devices = [str(d).strip().lower() for d in raw_devices if str(d).strip()]
        else:
            devices = []
        if not devices:
            dev = str(s.get("device", "")).strip().lower()
            devices = [dev] if dev else []
        enabled = bool(s.get("enabled", False))

        t1 = _step_seconds(s)

        try:
            t2 = max(0, int(float(s.get("seconds_off", 0) or 0)))
        except Exception:
            t2 = 0

        if t1 > 0:
            for dev in devices:
                expanded.append({
                    "device": dev,
                    "enabled": enabled,
                    "seconds": t1,
                    **({"percent": s.get("percent")} if "percent" in s else {})
                })

        if t2 > 0:
            for dev in devices:
                expanded.append({
                    "device": dev,
                    "enabled": (not enabled),
                    "seconds": t2,
                    **({"percent": s.get("percent")} if "percent" in s else {})
                })

    return expanded


def build_manual_page(parent, accent="#4B0082"):
    frame = ctk.CTkFrame(parent, fg_color="transparent", corner_radius=0, border_width=0)

    # -------------------- Header --------------------
    ctk.CTkLabel(
        frame,
        text="Ручное управление",
        font=ctk.CTkFont(family="Montserrat", size=18, weight="bold"),
        text_color="#0B1220"
    ).pack(anchor="n", pady=(8, 6))

    # -------------------- SCADA small --------------------
    scada = ctk.CTkFrame(
        frame,
        fg_color="#F8FAFC",
        corner_radius=16,
        border_width=1,
        border_color="#CBD5E1"
    )
    scada.pack(fill="x", padx=40, pady=(6, 10))

    headers = ["T0", "T1", "T2", "T3", "P0"]
    units = ["°C", "°C", "°C", "°C", "bar"]

    for i in range(5):
        scada.grid_columnconfigure(i, weight=1)

    for col, text in enumerate(headers):
        ctk.CTkLabel(
            scada,
            text=text,
            font=ctk.CTkFont(family="Montserrat", size=11, weight="normal"),
            text_color="#6B7280"
        ).grid(row=0, column=col, padx=14, pady=(8, 1))

    # --- value labels (важно: сохраняем ссылки на лейблы значений) ---
    value_labels = []
    for col in range(5):
        row_val = ctk.CTkFrame(scada, fg_color="transparent")
        row_val.grid(row=1, column=col, padx=14, pady=(0, 8), sticky="n")

        val_lbl = ctk.CTkLabel(
            row_val,
            text="0.0",
            font=ctk.CTkFont(family="Montserrat", size=18, weight="normal"),
            text_color="#111827"
        )
        val_lbl.pack(side="left")

        unit_lbl = ctk.CTkLabel(
            row_val,
            text=f" {units[col]}",
            font=ctk.CTkFont(family="Montserrat", size=10, weight="normal"),
            text_color="#9CA3AF"
        )
        unit_lbl.pack(side="left", pady=(3, 0))

        value_labels.append(val_lbl)

    t0_lbl = value_labels[0]
    t1_lbl = value_labels[1]
    t2_lbl = value_labels[2]
    t3_lbl = value_labels[3]
    p0_lbl = value_labels[4]

    # -------------------- Controls container --------------------
    controls = ctk.CTkFrame(frame, fg_color="transparent")
    controls.pack(fill="x", padx=40, pady=(2, 0))
    controls.grid_columnconfigure(0, weight=1)

    # -------------------- Manual compact table --------------------
    table = ctk.CTkFrame(
        controls,
        fg_color="#F8FAFC",
        corner_radius=16,
        border_width=1,
        border_color="#CBD5E1",
    )
    table.grid(row=0, column=0, sticky="ew", pady=(0, 2))
    table.grid_propagate(True)
    table.grid_columnconfigure(0, weight=1, uniform="manual_halves")
    table.grid_columnconfigure(1, weight=1, uniform="manual_halves")

    v_heater_1 = ctk.BooleanVar(value=False)
    v_heater_2 = ctk.BooleanVar(value=False)
    v_heater_3 = ctk.BooleanVar(value=False)
    v_pump = ctk.BooleanVar(value=False)
    v_valve = ctk.BooleanVar(value=False)

    # Держим дочерние панели внутри рамки с отступом. Так их фон не
    # перекрывает обводку общей карточки.
    heater_panel = ctk.CTkFrame(table, fg_color="transparent")
    heater_panel.grid(row=0, column=0, sticky="new", padx=(10, 14), pady=8)
    heater_panel.grid_columnconfigure(0, weight=1)
    limits_panel = ctk.CTkFrame(table, fg_color="transparent")
    limits_panel.grid(row=0, column=1, sticky="new", padx=(14, 10), pady=8)
    limits_panel.grid_columnconfigure(0, weight=1)

    temperature_frame = ctk.CTkFrame(
        controls,
        fg_color="#EEF2FF",
        corner_radius=14,
        border_width=1,
        border_color="#C7D2FE",
    )
    temperature_frame.grid(row=1, column=0, sticky="ew", pady=(8, 0))
    ctk.CTkLabel(
        temperature_frame,
        text="Поддержание средней температуры:",
        font=ctk.CTkFont(family="Montserrat", size=13, weight="normal"),
        text_color="#0B1220",
    ).grid(row=0, column=0, sticky="w", padx=(14, 8), pady=7)
    target_temperature_entry = ctk.CTkEntry(
        temperature_frame, width=100, height=TOUCH_CONTROL_HEIGHT, justify="center",
        font=ctk.CTkFont(family="Montserrat", size=14),
    )
    target_temperature_entry.grid(row=0, column=1, sticky="w", padx=(0, 5), pady=7)
    target_temperature_entry.insert(0, f"{DEFAULT_TARGET_C:g}")
    ctk.CTkLabel(temperature_frame, text="°C", font=ctk.CTkFont(family="Montserrat", size=12), text_color="#6B7280").grid(row=0, column=2, sticky="w", padx=(0, 8))
    temperature_control_var = ctk.BooleanVar(value=False)
    temperature_control_toggle = ToggleButton(temperature_frame, variable=temperature_control_var)
    temperature_control_toggle.grid(row=0, column=3, sticky="w", pady=7)

    zones_frame = ctk.CTkFrame(controls, fg_color="transparent")
    zones_frame.grid(row=2, column=0, sticky="ew", pady=(8, 0))
    for column in range(4):
        zones_frame.grid_columnconfigure(column, weight=1, uniform="temperature_zones")

    def _zone_card(column: int, title: str):
        card = ctk.CTkFrame(
            zones_frame,
            height=72,
            fg_color="#F8FAFC",
            corner_radius=14,
            border_width=1,
            border_color="#CBD5E1",
        )
        card.grid(
            row=0,
            column=column,
            sticky="ew",
            padx=(0 if column == 0 else 5, 0 if column == 3 else 5),
        )
        card.grid_propagate(False)
        ctk.CTkLabel(
            card,
            text=title,
            font=ctk.CTkFont(family="Montserrat", size=12),
            text_color="#64748B",
        ).pack(pady=(7, 0))
        value_label = ctk.CTkLabel(
            card,
            text="--",
            font=ctk.CTkFont(family="Montserrat", size=19, weight="bold"),
            text_color="#64748B",
        )
        value_label.pack(pady=(0, 7))
        return value_label

    average_temperature_card_lbl = _zone_card(0, "Средняя температура")
    heater_power_card_labels = [
        _zone_card(number, f"Нагреватель {number}")
        for number in range(1, 4)
    ]

    temperature_graph = AverageTemperatureGraph(controls)
    temperature_graph.grid(row=3, column=0, sticky="ew", pady=(8, 0))

    sensor_fault_lbl = ctk.CTkLabel(
        controls,
        text="Датчики: ожидание данных",
        anchor="w",
        font=ctk.CTkFont(family="Montserrat", size=12, weight="bold"),
        text_color="#64748B",
    )
    sensor_fault_lbl.grid(row=4, column=0, sticky="ew", pady=(6, 0), padx=4)

    devices_ui = {
        "нагреватель_1": _table_row(heater_panel, 0, "нагреватель 1", True, v_heater_1),
        "нагреватель_2": _table_row(heater_panel, 1, "нагреватель 2", True, v_heater_2),
        "нагреватель_3": _table_row(heater_panel, 2, "нагреватель 3", True, v_heater_3),
        "насос": _table_row(heater_panel, 3, "насос", False, v_pump),
        "концевик_1": _table_status_row(limits_panel, 0, "концевик 1", False),
        "концевик_2": _table_status_row(limits_panel, 1, "концевик 2", False),
        "клапан": _table_row(limits_panel, 3, "клапан", False, v_valve),
    }


    # Инициализируем датчик давления до lgpio-диммеров, чтобы I2C успел
    # открыть шину без влияния zero-cross GPIO callbacks.
    pressure_sensor = PressureSensor()

    heater_dimmers = {
        "нагреватель_1": get_heater_1_dimmer(),
        "нагреватель_2": get_heater_2_dimmer(),
        "нагреватель_3": get_heater_3_dimmer(),
    }
    pump_relay = get_pump_relay()
    valve_relay = get_valve_relay()
    temperature_controller = ThreeZoneTemperatureController(heater_dimmers.values())
    manual_journal_name = "Ручное управление"
    device_titles = {
        "нагреватель_1": "Нагреватель 1",
        "нагреватель_2": "Нагреватель 2",
        "нагреватель_3": "Нагреватель 3",
        "насос": "Насос",
        "клапан": "Клапан",
    }

    def _log_manual_action(details: str):
        journal_add_event(manual_journal_name, "ручное управление", details=details)

    def _show_output_error(output):
        err = output.last_error
        if err is not None:
            print(f"Не удалось переключить {output.name}: {err}")
        else:
            print(f"Не удалось переключить {output.name}: аппаратный модуль недоступен")

    def _set_relay(relay, enabled: bool) -> bool:
        if relay.set_enabled(enabled):
            return True
        _show_output_error(relay)
        return False

    def _set_power_entry(device_row: dict, percent: int):
        power_var = device_row.get("power_var")
        power_entry = device_row.get("power_entry")
        if power_var is not None:
            power_var.set(percent)
        if power_entry is not None:
            power_entry.delete(0, "end")
            power_entry.insert(0, _format_pct(percent))

    def _set_heater(device_name: str, enabled: bool) -> bool:
        heater_row = devices_ui[device_name]
        dimmer = heater_dimmers[device_name]
        if enabled:
            percent = DEFAULT_POWER_PERCENT
            _set_power_entry(heater_row, percent)
            ok = dimmer.set_enabled(True, percent=percent)
        else:
            ok = dimmer.set_enabled(False)
        if ok:
            return True
        _show_output_error(dimmer)
        return False

    manual_output_handlers = {
        "нагреватель_1": lambda enabled: _set_heater("нагреватель_1", enabled),
        "нагреватель_2": lambda enabled: _set_heater("нагреватель_2", enabled),
        "нагреватель_3": lambda enabled: _set_heater("нагреватель_3", enabled),
        "насос": lambda enabled: _set_relay(pump_relay, enabled),
        "клапан": lambda enabled: _set_relay(valve_relay, enabled),
    }

    def _bind_manual_toggle(
        device_name: str,
        device_row: dict,
        on_change=None,
        *,
        interrupts_temperature_control: bool = False,
    ):
        toggle = device_row.get("toggle")
        if toggle is None:
            return

        def _apply_toggle():
            # Поддержание средней температуры управляет только
            # нагревателями. Насос и клапан можно переключать независимо,
            # не сбрасывая автоматическое удержание.
            if interrupts_temperature_control and temperature_controller.enabled:
                temperature_controller.stop(turn_off=False)
                temperature_control_var.set(False)
                temperature_control_toggle._update_style()
                _log_manual_action("Поддержание температуры выключено ручным переключением нагревателя")
            previous = bool(toggle.var.get())
            toggle.toggle()
            enabled = bool(toggle.var.get())
            if callable(on_change) and on_change(enabled) is False:
                toggle.var.set(previous)
                toggle._update_style()
                return
            title = device_titles.get(device_name, device_name)
            if enabled and device_name.startswith("нагреватель_"):
                percent = devices_ui[device_name]["power_var"].get()
                _log_manual_action(f"{title} включён на {percent} %")
            else:
                state = "включён" if enabled else "выключен"
                _log_manual_action(f"{title} {state}")

        def _on_toggle():
            if is_program_active():
                _confirm_dialog(
                    frame,
                    "Остановить программу?",
                    lambda: (request_program_stop(), _apply_toggle())
                )
                return
            _apply_toggle()

        toggle.configure(command=_on_toggle)

    for device_name, row in devices_ui.items():
        _bind_manual_toggle(
            device_name,
            row,
            manual_output_handlers.get(device_name),
            interrupts_temperature_control=device_name.startswith("нагреватель_"),
        )

    def _target_temperature() -> float:
        try:
            target = float(target_temperature_entry.get().strip().replace(",", "."))
        except ValueError:
            target = DEFAULT_TARGET_C
        target = max(0.0, min(500.0, target))
        target_temperature_entry.delete(0, "end")
        target_temperature_entry.insert(0, f"{target:g}")
        return target

    def _set_temperature_control(enabled: bool):
        if enabled:
            target = _target_temperature()
            temperature_controller.start(target)
            _log_manual_action(f"Поддержание температуры включено на {target:g} °C")
            return True
        temperature_controller.stop()
        for device_name in ("нагреватель_1", "нагреватель_2", "нагреватель_3"):
            toggle = devices_ui[device_name]["toggle"]
            toggle.var.set(False)
            toggle._update_style()
        _log_manual_action("Поддержание температуры выключено")
        return True

    def _on_temperature_control_toggle():
        def _apply():
            enabled = not bool(temperature_control_var.get())
            temperature_control_var.set(enabled)
            temperature_control_toggle._update_style()
            _set_temperature_control(enabled)

        if is_program_active():
            _confirm_dialog(frame, "Остановить программу?", lambda: (request_program_stop(), _apply()))
            return
        _apply()

    temperature_control_toggle.configure(command=_on_temperature_control_toggle)
    target_temperature_entry.bind("<Return>", lambda _event=None: _target_temperature(), add="+")
    target_temperature_entry.bind("<FocusOut>", lambda _event=None: _target_temperature(), add="+")

    def _apply_heater_power(device_name: str):
        heater_row = devices_ui[device_name]
        power_entry = heater_row.get("power_entry")
        power_var = heater_row.get("power_var")
        if power_entry is None or power_var is None:
            return
        percent = _clamp(_parse_pct(power_entry.get(), fallback=power_var.get()))
        _set_power_entry(heater_row, percent)
        if bool(heater_row["var"].get()):
            if heater_dimmers[device_name].set_power(percent):
                title = device_titles.get(device_name, device_name)
                _log_manual_action(f"{title}: мощность изменена на {percent} %")

    for device_name in ("нагреватель_1", "нагреватель_2", "нагреватель_3"):
        heater_entry = devices_ui[device_name].get("power_entry")
        if heater_entry is not None:
            heater_entry.bind("<Return>", lambda _event=None, name=device_name: _apply_heater_power(name), add="+")
            heater_entry.bind("<FocusOut>", lambda _event=None, name=device_name: _apply_heater_power(name), add="+")

    def _shutdown_manual_outputs(_event=None):
        temperature_controller.stop(turn_off=False)
        for dimmer in heater_dimmers.values():
            dimmer.off()
        pump_relay.off()
        valve_relay.off()

    frame.bind("<Destroy>", _shutdown_manual_outputs, add="+")

    limit1_row = devices_ui.get("концевик_1", {})
    limit2_row = devices_ui.get("концевик_2", {})
    limit1_lamp = limit1_row.get("lamp")
    limit1_lbl = limit1_row.get("status_label")
    limit2_lamp = limit2_row.get("lamp")
    limit2_lbl = limit2_row.get("status_label")

    # -------------------- TEMPS/PRESSURE UPDATE --------------------
    reader = QuadMAX31865(filter_50hz=True)
    door_sensors = get_door_sensors()


    def _update_sensors():
        if not frame.winfo_exists():
            try:
                reader.close()
            except Exception:
                pass
            return

        try:
            t0, t1, t2, t3 = reader.read()
        except Exception as exc:
            print(f"Не удалось прочитать датчики температуры: {exc}")
            t0 = t1 = t2 = t3 = None

        # отображаем "--" если fault/None
        t0_lbl.configure(text="--" if t0 is None else f"{t0:.1f}")
        t1_lbl.configure(text="--" if t1 is None else f"{t1:.1f}")
        t2_lbl.configure(text="--" if t2 is None else f"{t2:.1f}")
        t3_lbl.configure(text="--" if t3 is None else f"{t3:.1f}")

        temperature_controller.update((t0, t1, t2, t3))
        average = temperature_controller.last_average_c
        if average is None:
            average_temperature_card_lbl.configure(text="-- °C", text_color="#F59E0B")
        else:
            average_temperature_card_lbl.configure(text=f"{average:.1f} °C", text_color="#F59E0B")
        for device_name, label in zip(
            ("нагреватель_1", "нагреватель_2", "нагреватель_3"),
            heater_power_card_labels,
        ):
            heater_power = heater_dimmers[device_name].power_percent
            label.configure(
                text=f"{heater_power} %",
                text_color="#16A34A" if heater_power > 0 else "#64748B",
            )
        temperature_graph.add_sample(
            average,
            target_c=temperature_controller.target_c,
        )
        try:
            _, absolute_pressure_kpa = pressure_sensor.read_pressure_kpa()
        except Exception as exc:
            print(f"Не удалось прочитать датчик давления: {exc}")
            absolute_pressure_kpa = None

        if absolute_pressure_kpa is None:
            p0_lbl.configure(text="--")
        else:
            pressure_bar = absolute_pressure_kpa / 100.0
            p0_lbl.configure(text=f"{pressure_bar:.3f}")

        failed_sensors = [
            name for name, value in zip(("T0", "T1", "T2", "T3"), (t0, t1, t2, t3))
            if value is None
        ]
        if absolute_pressure_kpa is None:
            failed_sensors.append("P0")
        if failed_sensors:
            sensor_fault_lbl.configure(
                text=f"⚠ Нет сигнала: {', '.join(failed_sensors)}",
                text_color="#DC2626",
            )
        else:
            sensor_fault_lbl.configure(text="● Все датчики исправны", text_color="#16A34A")

        try:
            d1_closed, d2_closed = door_sensors.read()
            telemetry_doors = {"door_1": d1_closed, "door_2": d2_closed}
        except Exception as exc:
            print(f"Не удалось прочитать концевики двери: {exc}")
            d1_closed = d2_closed = False
            telemetry_doors = {"door_1": None, "door_2": None}

        if limit1_lamp is not None and limit1_lbl is not None:
            _paint_door_indicator(limit1_lamp, limit1_lbl, d1_closed)
        if limit2_lamp is not None and limit2_lbl is not None:
            _paint_door_indicator(limit2_lamp, limit2_lbl, d2_closed)

        telemetry = getattr(frame.winfo_toplevel(), "telemetry", None)
        if telemetry is not None:
            try:
                telemetry.publish_measurement(
                    temperatures_c={"t0": t0, "t1": t1, "t2": t2, "t3": t3},
                    vacuum_kpa=None,
                    absolute_pressure_kpa=absolute_pressure_kpa,
                    doors_closed=telemetry_doors,
                )
            except Exception as exc:
                print(f"Не удалось поставить измерение в очередь: {exc}")

        frame.after(1000, _update_sensors)

    frame.after(0, _update_sensors)

    return frame
